#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

int cont = 0;

int main(int argc, char * argv[]) {

    int n;

   for (int i=0; i<4; i++) {
        fork();
   }

    printf("%d\n", getpid());
    return EXIT_SUCCESS;
}