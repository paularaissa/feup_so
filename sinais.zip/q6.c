#include <errno.h>
#include <signal.h> // biblioteca para trabalhar com sinais
#include <stdio.h>
#include <stdlib.h>
#include <string.h> // biblioteca com funções específicas para Strings
#include <unistd.h> // biblioteca para trabalhar com processos

/*
Ver documentação de signal em https://man7.org/linux/man-pages/man7/signal.7.html
*/

static void handler1() { 
    printf("received SIGUSR1\n"); 
}

static void handler2() { 
    printf("received SIGUSR2\n"); 
}

static void handler3() { 
    printf("received SIGHUP\n"); 
}

/* Estrutura da função signal
void (*signal(int sig, void (*func)(int)))(int)
sig − Valor inteiro que corresponde a um sinal para uma função de handling (instrução a ser executada a partir do número do sinal).
func − Apontador para uma função. Pode ser uma função definida pelo programador ou algumas das funções predefinidas da 
    biblioteca signals.h <ver documentação>
*/

int main(int argc, char* argv[]) {
    printf("My PID is %d\n", getpid());
    /* SIGUSR1 : User-defined signal 1 */
    /* SIG_ERR : Utilizado para indicar uma falha na configuração do sinal */
    if (signal(SIGUSR1, handler1) == SIG_ERR) { 
        fprintf(stderr, "Can't catch SIGUSR1: %s", strerror(errno));
        exit(EXIT_FAILURE);
    }
    /* SIGUSR2 :  User-defined signal 2 */
    if (signal(SIGUSR2, handler2) == SIG_ERR) {
        fprintf(stderr, "Can't catch SIGUSR2: %s", strerror(errno));
        exit(EXIT_FAILURE);
    }
    /* SIGHUP : Hangup detected on controlling terminal */
    if (signal(SIGHUP, handler3) == SIG_ERR) {
        fprintf(stderr, "Can't catch SIGHUP: %s", strerror(errno));
        exit(EXIT_FAILURE);
    }
    /* stick around ... */
    for ( ; ; )
    pause();
    /* precisa de control+c para sair */
}