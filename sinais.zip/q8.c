#include <errno.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

static void handler_parent() { 
    printf("%d: Parent received signal\n", getpid()); 
}

static void handler_child() { 
    printf("%d: Child received signal\n", getpid()); 
}

int main(int argc, char* argv[]) {
    pid_t pid;
    if (signal(SIGUSR1, handler_parent) == SIG_ERR) { 
        fprintf(stderr, "Can't catch SIGUSR1: %s", strerror(errno));
        exit(EXIT_FAILURE);
    }
    if (signal(SIGUSR2, handler_child) == SIG_ERR) { 
        fprintf(stderr, "Can't catch SIGUSR2: %s", strerror(errno));
        exit(EXIT_FAILURE);
    }
    if ((pid = fork()) < 0) { 
        exit(EXIT_FAILURE);
    }
    /* PROCESSO PAI */
    else if (pid > 0) {
        /* kill() envia sinais para outro processo. */
        /* veja documentação em https://man7.org/linux/man-pages/man2/kill.2.html */
        kill(pid, SIGUSR2);
        pause();
    /* PROCESSO FILHO */
    } else {
        /* getppid() irá pegar o id do processo filho, que foi atribuído quando foi criado */
        /* veja documentação em https://man7.org/linux/man-pages/man2/getpid.2.html */
        kill(getppid(), SIGUSR1);
        pause();
    }
}