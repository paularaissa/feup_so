#include <sys/wait.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define READ_END 0
#define WRITE_END 1

#define LINESIZE 256

int main(int argc, char* argv[]) {
    int nbytes, fd[2]; /* File descriptors pro Pipe */
    pid_t pid; /* Variável para armazenar o pid*/
    char line[LINESIZE]; /* String a ser passada entre processos */

    /* Criando nosso Pipe */
    if (pipe(fd) < 0) {
        perror("pipe error");
        exit(EXIT_FAILURE);
    }

    /* Criando o processo filho*/
    if ((pid = fork()) < 0) {
        perror("fork error");
        exit(EXIT_FAILURE); // similar a exit(1);
    }

    /* Processo Pai*/
    else if (pid > 0) {
        /* No pai, vamos ESCREVER, então vamos fechar a LEITURA do Pipe neste lado */
        close(fd[READ_END]);
        printf("Parent process with pid %d\n", getpid());
        printf("Messaging the child process (pid %d):\n", pid);
        snprintf(line, LINESIZE, "Hello! I'm your parent pid %d!\n", getpid());

        /* Escrevendo a string no pipe */
        /* o processo pai escreve uma mensagem utilizando o file descriptor de escrita utilizando a chamada de sistema write */
        if ((nbytes = write(fd[WRITE_END], line, strlen(line))) < 0) {
            fprintf(stderr, "Unable to write to pipe: %s\n", strerror(errno));
        }
        close(fd[WRITE_END]);
        /* wait for child and exit */
        if ( waitpid(pid, NULL, 0) < 0) {
            fprintf(stderr, "Cannot wait for child: %s\n", strerror(errno));
        }
        exit(EXIT_SUCCESS);
    }
    /* Processo Filho*/
    else {
        /* No filho, vamos ler. Então vamos fechar a entrada de ESCRITA do pipe */
        close(fd[WRITE_END]);
        printf("Child process with pid %d\n", getpid());
        printf("Receiving message from parent (pid %d):\n", getppid());
        /* Lendo o que foi escrito no pipe, e armazenando isso em 'line' */
        /* lê dados do file descriptor de leitura do pipe */
        /* o processo filho fica esperando por dados a serem lidos */
        /*  
        fd[READ_END] - file descriptor, para especificar o pipe que está usando
        line - endereço de memória
        LINESIZE - número em bytes, dizendo que a partir daquele endereço de memória
        (do segundo parâmetro), quantas informações vamos escrever/ler pelo pipe.   
        */
        if ((nbytes = read(fd[READ_END], line, LINESIZE)) < 0 ) {
            fprintf(stderr, "Unable to read from pipe: %s\n", strerror(errno));
        }
        close(fd[READ_END]);
        /* write message from parent */
        write(STDOUT_FILENO, line, nbytes);
        /* exit gracefully */
        exit(EXIT_SUCCESS);
    }
}