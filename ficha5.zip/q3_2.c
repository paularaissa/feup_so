#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>

int main(int argc, char * argv[]) {
    int p = 14;
    if (!fork()) {
        printf("CHILD: before changing the variable:\n");
        printf("address of p is %p and value is %d\n", (void*)&p, p);
        p = 25;
        printf("CHILD: after changing the variable:\n");
        printf("address of p is %p and value is %d\n", (void*)&p, p);
        printf(" CHILD: exiting\n");
        exit(0);
    } else {
        printf("PARENT: as is\n");
        printf("address of p is %p and value is %d\n", (void*)&p, p);
        wait(NULL);
        printf("PARENT: after child exited\n");
        printf("address of p is %p and value is %d\n", (void*)&p, p);
    }
}