#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>

int main(int argc, char *argv[]) {
    /* ------ create and read matrix ------ */
    char* infile = argv[1];
    int nprocs = atoi(argv[2]);
    int threshold = atoi(argv[3]);
    FILE *fp;

    /* Faz a leitura da matriz que está num ficheiro e carrega para um array */
    if((fp = fopen(infile,"r")) == NULL){
        perror("cannot open file");
        exit(EXIT_FAILURE);
    }
    size_t str_size = 0;
    char* str = NULL;
    getline(&str, &str_size, fp);
    int n = atoi(str);
    int matrix[n][n];
    int i = 0, j = 0;
    while (getline(&str, &str_size, fp) > 0) {
        char* token = strtok(str," ");
        while(token != NULL) {
            matrix[i][j]=atoi(token);
            token=strtok(NULL," ");
            j++;
        }
        i++;
        j=0;
    }
    fclose(fp);

    /* Imprime a matriz */
    printf("IMPRESSÃO DA MATRIZ\n");
    for(i = 0; i < n; i++){
        for(j = 0; j < n; j++){
            printf("%d ", matrix[i][j]);
        }
        printf("\n");
    }

    /* ------ setup shared memory ------ */
    /*  mmap(addr, length, prot, flags, fd, offset) 
    addr - endereço onde esse mapeamento vai ser feito
    length - representa o tamanho dessa memória
    prot - representa a proteção dessa memória
    flags - determina se as atualizações do mapeamento são visíveis para outros processos que 
        mapeiam a mesma região e se as atualizações são realizadas no arquivo.
    fd - descritor do arquivo usado para esse mapeamento
    offset - offse
    Confira a documentação em https://man7.org/linux/man-pages/man2/mmap.2.html
    */
    int *partials = mmap(NULL, nprocs*sizeof(int), PROT_READ|PROT_WRITE, MAP_SHARED|MAP_ANONYMOUS, 0, 0);
    /* PROT_READ | PROT_WRITE proteção para leitura e escrita na região mapeada.
    MAP_PRIVATE | MAP_ANONYMOUS. MAP_PRIVATE é usado porque a região de mapeamento não é 
        compartilhada com outros processos, e MAP_ANONYMOUS é usado porque aqui não mapeamos nenhum ficheiro
    */
    if(partials == MAP_FAILED){
        perror("mmap");
        exit(EXIT_FAILURE);
    }
    /* Inicializar o vetor partials com 0 */
    for(i = 0; i < nprocs; i++) {
        partials[i] = 0;
    }

    /* ------ start nprocs and do work ------ */
    /* Cria os processos filhos de acordo com nprocs (valor recebido via terminal) */
    for(i = 0; i < nprocs; i++){
        pid_t pid;
        if ((pid = fork()) < 0){ // Valida se houve falha na criação do processo
            perror("fork");
            exit(EXIT_FAILURE);
        }
        if(pid == 0){ // Em caso de sucesso, entra nesse bloco de código
            for(int j = 0; j < n; j++) 
                if(j % nprocs == i) // % simboliza o módulo da divisão
                    for(int k = 0; k < n; k++) 
                        if(matrix[j][k] > threshold)
                            partials[i]++;
            exit(EXIT_SUCCESS);
        }
    }

    /* ------ wait for nprocs to finish ------- */
    for(i = 0; i < nprocs; i++) {
        if (waitpid(-1, NULL, 0) < 0) {
            perror("waitpid");
            exit(EXIT_FAILURE);
        }
    }

    /* ler resultados enviados pelos processos filhos */
    int total = 0;
    for(i = 0; i < nprocs; i++)
        total += partials[i];
    printf("\nTotal: %d\n",total);

    /* ------ release shared memory ------ */
    /* munmap(): Libera a memória alocada pelo mmap 
    Veja a documentação em 
    */
    if (munmap(partials, sizeof(partials)) < 0) {
        perror("munmap");
        exit(EXIT_FAILURE);
    }
    exit(EXIT_SUCCESS);

    /* Para executar é necessário passar via terminal o nome do ficheiro que está a matriz,
    um valor inteiro para o número de processos a serem criados (nprocs) e outro valor inteiro
    para o threshold utilizado nos cálculos.
    ./q5 matriz.txt 2 3
     */
}