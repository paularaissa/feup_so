/* Primitivas de Sincronização */

#include <stdio.h>
#include <pthread.h>

int count=0; /* Contador */

// Inicializa o mutex com os atributos por default
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER; /* lock para o contador */

void * inc(void * arg)
{
    /* pthread_mutex_lock() Obter o lock no mutex. Retorna 0 se OK, valor positivo se erro. 
    lock é a variável que representa o mutex
    */
    pthread_mutex_lock(&lock);
    for (int i=0; i<10000; i++) count++; //reduir i para 20, para tornar o exemplo mais fácil de perceber
    
    /* pthread_mutex_unlock() Libertar o lock. Retorna 0 se OK, valor positivo se erro. 
    lock é a variável que representa o mutex
    */
    pthread_mutex_unlock(&lock);
    return NULL;
}


void * dec(void *arg)
{
    //int contador = count;
    
    pthread_mutex_lock(&lock);
    for (int i=count; i>0; i--)
    {
        count --;
        //printf("%s: %i\n", (char *)arg, contador);
        if (count < 0)
            printf(".");
    }
    //sched_yield();
    pthread_mutex_unlock(&lock);
    return NULL;
}

int main()
{
    printf("Start: %d\n",count);

    /* pthread_mutex_init() Inicia um mutex. Retorna 0 se OK, valor positivo se erro. 
    O primeiro atributo é a variável que representa o mutex.
    O segundo atributo permite especificar atributos do mutex. Se NULL o mutex é iniciado 
    com os atributos por default.
    Veja a documentação em https://man7.org/linux/man-pages/man3/pthread_mutex_init.3p.html
    */
    pthread_mutex_init(&lock,NULL);

    pthread_t tid1, tid2;
    pthread_create(&tid1,NULL,inc,NULL);
    pthread_create(&tid2,NULL,inc,NULL);
    pthread_join(tid1,NULL);
    pthread_join(tid2,NULL);
    
    /*
    
    */
    pthread_mutex_destroy(&lock);
    printf("End: %d\n",count);
}
