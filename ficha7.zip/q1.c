#include <stdio.h>
#include <pthread.h>

int count=0;

void * inc(void * arg) {
    //reduzir i para 20, para tornar o problema mais fácil de perceber
    for (int i=0; i<10000; i++) count++;
    return NULL;
}

/*int inc2(void * arg) {
    int contador = 0;
    
    for (int i=0; i<20; i++) contador++;
    return contador;
}*/

int main()
{
    printf("Start: %d\n",count);
    /* pthread_t : Handle para pthread, isto é, um valor inteiro que permite identificar a thread no sistema */
    pthread_t tid1, tid2;
    
    /* pthread_create() inicializa uma thread. Essa função recebe 4 argumentos:
     - O primeiro argumento é um apontador para thread_id que é definido por esta função.
     - O segundo argumento especifica atributos. Se o valor for NULL, os atributos padrão devem ser usados.
     - O terceiro argumento é o nome da função a ser executada para a thread a ser criada.
     - O quarto argumento é usado para passar argumentos para a função 'inc'.
    veja a documentação em https://man7.org/linux/man-pages/man3/pthread_create.3.html
    */
    pthread_create(&tid1,NULL,inc,NULL);
    pthread_create(&tid2,NULL,inc,NULL);

    /* pthread_join() bloqueia a thread de chamada até que a thread com identificador igual 
    ao primeiro argumento termine. Similar à função wait() para processos.
    Essa função recebe 2 argumentos:
     - O primeiro argumento é o identificador da thread a esperar que termine.
     - O segundo argumento é o endereço de um apontador para o valor de retorno da thread. Se o valor 
        de retorno for desprezável indique NULL.
    Veja a documentação em https://man7.org/linux/man-pages/man3/pthread_join.3.html
    */
    pthread_join(tid1,NULL);
    pthread_join(tid2,NULL);

    printf("End: %d\n",count);
}

// Tentem colocar comentários para executar uma thread de cada vez