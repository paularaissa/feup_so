#include <sys/wait.h>
#include <sys/socket.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

#define CHANNEL0 0
#define CHANNEL1 1

#define DATA0 "In every walk with nature..."
#define DATA1 "...one receives far more than he seeks."


int main(int argc, char* argv[]) {
    int sockets[2];
    char buf[1024];
    pid_t pid;
    /* 
    socketpair() cria um par de soquetes conectados de acordo com o domínio, tipo e protocolo.
    veja documentação em https://man7.org/linux/man-pages/man2/socketpair.2.html
    https://man7.org/linux/man-pages/man3/socketpair.3p.html
    Essa função é utilizada para abrir o canal de comunicação, semelhante ao pipe()s
    */
    if (socketpair(AF_UNIX, SOCK_STREAM, 0, sockets) < 0) {
        perror("opening stream socket pair");
        exit(1);
    }

    /* Cria um processo filho */
    if ((pid = fork()) < 0) {
        perror("fork");
        return EXIT_FAILURE;
    }

    /* PROCESSO FILHO */
    else if (pid == 0) {
        /* this is the child */

        /* sockets[] funciona de maneira similar ao file descriptor, porém passo a fechar
        o canal dedicado a cada processo. Ao fechar CHANNEL0 estamos a fechar o canal de 
        comunicação do processo pai */
        close(sockets[CHANNEL0]);

        /* a função read() é a mesma que usamos no pipe */
        if (read(sockets[CHANNEL1], buf, sizeof(buf)) < 0)
            perror("reading stream message");
        printf("message from %d-->%s\n", getppid(), buf);
        /* a função write() é a mesma que usamos no pipe */
        if (write(sockets[CHANNEL1], DATA1, sizeof(DATA1)) < 0)
            perror("writing stream message");
        
        /* Fecha-se o canal de comunicação do processo filho */
        close(sockets[CHANNEL1]);
        
        return EXIT_SUCCESS;
    }
    /* PROCESSO PAI */
    else {
        /* Fecha o canal de comunicação do processo filho, já que vamos 
        configurar a leitura e escrita. */
        close(sockets[CHANNEL1]);

        if (write(sockets[CHANNEL0], DATA0, sizeof(DATA0)) < 0)
            perror("writing stream message");
        if (read(sockets[CHANNEL0], buf, sizeof(buf)) < 0)
            perror("reading stream message");
        printf("message from %d-->%s\n", pid, buf);

        /* Encerra a comunicação no processo pai */
        close(sockets[CHANNEL0]);

        /* Espera que o filho termine de executar para encerrar */
        if (waitpid(pid, NULL, 0) < 0) {
            perror("did not catch child exiting");
        return EXIT_FAILURE;
    }
        return EXIT_SUCCESS;
    }
}