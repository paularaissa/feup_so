#include <unistd.h>
#include <stdio.h>
#include <pthread.h>

int count=0;
pthread_mutex_t lock;
pthread_cond_t not_zero;

void * inc(void * arg)
{
    for (int i=0; i<1000000; i++)
    {
        pthread_mutex_lock(&lock);
        count++;

        /* pthread_cond_signal(pthread cond t *cond) Acorda um dos threads bloqueados na variável cond. 
        Caso existam vários threads bloqueados, apenas um é acordado (nãoo é especificado qual). 
        Se nenhum thread estiver bloqueado na variável especificada, nada acontece.
        As funçã retorna 0 se OK, valor positivo se erro.
        */
        pthread_cond_signal(&not_zero);
        
        pthread_mutex_unlock(&lock);
    }
    return NULL;
}

/* Podemos alterar a função de decremento */
void * dec(void * arg)
{
    for (int i=0; i<1000000; i++)
    {
        pthread_mutex_lock(&lock); // O lock sobre o mutex deve ser feito deve ser feito antes de invocar pthread_cond_wait. Caso isso não seja feito, pode originar a perda do sinal e a função irá retornar um erro. 
        while (count == 0) {
            /* pthread_cond_wait() bloqueia o thread na variável de condição cond.
            Veja documentação em https://man7.org/linux/man-pages/man3/pthread_cond_wait.3p.html
            */
            pthread_cond_wait(&not_zero, &lock); // 
        }
        count--;
        if (count<0) write(1,".",1);
        pthread_mutex_unlock(&lock);
    }
    return NULL;
}

int main()
{
    printf("Start: %d\n",count);
    pthread_mutex_init(&lock,NULL);
    
    /* inicia uma variável de condição. Retorna 0 se OK, valor positivo se erro. 
    O primeiro parâmetro representa a variável de condição.
    O segundo parâmetro permite especificar atributos da variável de condição. Se NULL é iniciado com
    atributos por default.
    Outra foram de iniciar uma variável de condição (se estaticamente alocada) com
    os atributos por default é a seguinte:
    pthread_cond_t cond = PTHREAD_COND_INITIALIZER;
    */
    pthread_cond_init(&not_zero,NULL);

    pthread_t tid1, tid2;

    pthread_create(&tid1,NULL,inc,NULL);
    pthread_create(&tid2,NULL,dec,NULL);
    pthread_join(tid1,NULL);
    pthread_join(tid2,NULL);
    pthread_mutex_destroy(&lock);
    printf("End: %d\n",count);
}