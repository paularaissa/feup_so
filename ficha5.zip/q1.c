#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

int main(int argc, char * argv[]) {

    pid_t pid;
    int status;

    /* fork a child process */
    fork();

    /* fork another child process */
    fork();

    /* and fork another */
    fork();

    printf("teste\n");

    return EXIT_SUCCESS;
}